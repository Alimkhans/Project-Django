from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="customer")
    balance = models.IntegerField(default=0)

    class Meta:
        verbose_name = "Customer"
        verbose_name_plural = "Customers"

class Movie(models.Model):
    trailer_url = models.CharField(max_length=255, null=False)
    image_url = models.CharField(max_length=255, null=False)
    name = models.CharField(max_length=255, null=False)
    desc = models.CharField(max_length=255, null=False)
    price = models.IntegerField(null=False, default=9)

    
    class Meta:
        verbose_name = "Movie"
        verbose_name_plural = "Movies"