from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from .models import *
# Create your views here.


def logining(request):
    if request.method=="POST":
        user = authenticate(username=request.POST['username'], password=request.POST['password'])
        if user is not None:
            login(request, user)
            return redirect("home")
    return render(request, "App/autorize.html")
def index(request):
    return render(request, "App/index.html")
def aboutUs(request):
    return render(request, "App/about-us.html")
def news(request):
    return render(request, "App/news.html")
def reviews(request):
    return render(request, "App/reviews.html")

def payment(request):
    if request.method == "POST":
        user = User.objects.get(id=request.user.id)
        user.customer.balance += 100
        user.customer.save()
        user.save()
        return redirect("home")
    return render(request, "App/payment.html")

def register(request):
    if request.method=="POST":
        user = User.objects.create_user(
            first_name = request.POST['name'],
            email = request.POST['email'],
            password = request.POST['password'],
            username = request.POST['email']
        )
        customer = Customer.objects.create(user=user, balance=0)
        user.save()
        customer.save()
        return redirect("login")
    return render(request, "App/reg.html")